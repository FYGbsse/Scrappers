
function url_content(url){
    return $.get(url);
}


url_content("https://www.walmart.com/search/?query=16a").success(function(data){ 
  alert(data);
});